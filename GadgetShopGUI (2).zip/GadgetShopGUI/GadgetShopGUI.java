import java.awt.*;
import java.awt.event.*;
import javax.swing.*;
import java.util.ArrayList;



public class GadgetShopGUI implements ActionListener
{
    private JFrame frame;
    private JFrame frame2;

    /** 1 */
    private JLabel modelLabel;
    private JLabel priceLabel;
    private JLabel weightLabel;
    private JLabel sizeLabel;

    /** 2 */
    private JTextField modelTextbox;
    private JTextField priceTextbox;
    private JTextField weightTextbox;
    private JTextField sizeTextbox;

    /** 3 */
    private JLabel creditLabel;
    private JLabel memoryLabel;
    private JButton addMobileButton;
    private JButton addMP3PButton;

    /** 4 */
    private JTextField creditTextbox;
    private JTextField memoryTextbox;
    private JButton clearButton;
    private JButton displayAllButton;

    /** 5 */
    private JLabel phoneNoLabel;
    private JLabel durationLabel;
    private JLabel downloadLabel;
    private JLabel displayNumberLabel;

    /** 6 */
    private JTextField phoneNoTextbox;
    private JTextField durationTextbox;
    private JTextField downloadTextbox;
    private JTextField displayNumberTextbox;

    /** 7 */
    private JButton makeACallButton;
    private JButton downloadMusicButton;

    ArrayList<Gadget> item = new ArrayList <Gadget>();

    public GadgetShopGUI()
    {
        frame=new JFrame("Gadget Shop");
        Container contentPane = frame.getContentPane();

        /** 1 */
        modelLabel = new JLabel("Model:");
        priceLabel = new JLabel("Price:");
        weightLabel = new JLabel("Weight:");
        sizeLabel = new JLabel("Size:");

        /** 2 */
        modelTextbox = new JTextField(10);
        priceTextbox = new JTextField(10);
        weightTextbox = new JTextField(10);
        sizeTextbox = new JTextField(10);

        /** 3 */
        creditLabel = new JLabel("Credit:");
        memoryLabel = new JLabel("Memory:");
        addMobileButton = new JButton("Add Mobile");
        addMobileButton.addActionListener(this);
        addMP3PButton = new JButton("Add MP3 player");
        addMP3PButton.addActionListener(this);

        /** 4 */
        creditTextbox = new JTextField(10);
        memoryTextbox = new JTextField(10);
        clearButton = new JButton("Clear");
        clearButton.addActionListener(this);
        displayAllButton = new JButton("Display All");
        displayAllButton.addActionListener(this);

        /** 5 */
        phoneNoLabel = new JLabel("Phone No:");
        durationLabel = new JLabel("Duration:");
        downloadLabel = new JLabel("Download:");
        displayNumberLabel = new JLabel("Display Number:");

        /** 6 */
        phoneNoTextbox = new JTextField(10);
        durationTextbox = new JTextField(10);
        downloadTextbox = new JTextField(10);
        displayNumberTextbox = new JTextField(10);

        /** 7 */
        makeACallButton = new JButton("Make a Call");
        makeACallButton.addActionListener(this);
        downloadMusicButton = new JButton("Download Music");
        downloadMusicButton.addActionListener(this);

        contentPane.setLayout(new GridLayout(7,4));
        /** 1 */
        contentPane.add(modelLabel);
        contentPane.add(priceLabel);
        contentPane.add(weightLabel);
        contentPane.add(sizeLabel);

        /** 2 */
        contentPane.add(modelTextbox);
        contentPane.add(priceTextbox);
        contentPane.add(weightTextbox);
        contentPane.add(sizeTextbox);

        /** 3 */
        contentPane.add(creditLabel);
        contentPane.add(memoryLabel);
        contentPane.add(addMobileButton);
        contentPane.add(addMP3PButton);

        /** 4 */
        contentPane.add(creditTextbox);
        contentPane.add(memoryTextbox);
        contentPane.add(clearButton);
        contentPane.add(displayAllButton);

        /** 5 */
        contentPane.add(phoneNoLabel);
        contentPane.add(durationLabel);
        contentPane.add(downloadLabel);
        contentPane.add(displayNumberLabel);

        /** 6 */
        contentPane.add(phoneNoTextbox);
        contentPane.add(durationTextbox);
        contentPane.add(downloadTextbox);
        contentPane.add(displayNumberTextbox);

        /** 7 */
        contentPane.add(makeACallButton);
        contentPane.add(downloadMusicButton);

        frame.pack();
        frame.setVisible(true);

        
    }
    public static void main(String[] args)
    {
        GadgetShopGUI shop = new GadgetShopGUI();
        
    }
    public void actionPerformed(ActionEvent event)
    {
        String command = event.getActionCommand();

        if (command.equals("Add Mobile"))
        {
            Mobile newMobile = new Mobile(getModel(), getPrice(), getWeight(), getSize(), getCredit());

            item.add(newMobile);

            System.out.println(item.size());
            JOptionPane.showMessageDialog(frame, "A new Mobile is added");
            JOptionPane.showMessageDialog(frame, "   Activate your Sim card,please\n"+
                "         " + "   #Make a call#\n"
                + "Phone No:"+ "  " +"Duration:"+ "  " + "Display Number:"  );
        }
        else if(command.equals("Add MP3 player"))
        {
            MP3 newMP3 = new MP3(getModel(), getPrice(), getWeight(), getSize(), getMemory());  

            item.add(newMP3);

            System.out.println(item.size());  
            JOptionPane.showMessageDialog(frame, "A new MP3 player is added");
            JOptionPane.showMessageDialog(frame, "   Download some music for free,please\n"+
                "         " + "   #Fill in the following#\n"
                + "  " + "Download:"+ "  " + "Display Number:"  );
        }

        else if(command.equals("Display All"))
        {
            for (Gadget gadget : item) 
            {
                gadget.printDetails();

            }

        }
        else if(command.equals("Clear"))
        {
            Clear();
            clearScreen();

        }

        else if(command.equals("Make a Call"))
        {

            Mobile mobile = (Mobile) item.get(getDisplayNumber()-1);   
            mobile.MakingPhoneCall(getPhoneNo(), getDuration(), getDisplayNumber());

         
            for (Gadget gadget : item) 
            {
                gadget.printDetails();
                mobile.printDetailsPhoneCall();

            }

        }    
            else if (command.equals("Download Music"))
            {

                MP3 mp3 = (MP3) item.get(getDisplayNumber()-1);   
                mp3.DownloadMusic(getDownload(),getDisplayNumber());

         
                for (Gadget gadget : item) 
                {
                    gadget.printDetails();
                    mp3.printDetailsDownloadMusic();

                }

         
            }
        }

            public void Clear()
            {
                modelTextbox.setText("");
                priceTextbox.setText("");
                weightTextbox.setText("");
                sizeTextbox.setText("");
                creditTextbox.setText("");
                memoryTextbox.setText("");
                phoneNoTextbox.setText("");
                durationTextbox.setText("");
                downloadTextbox.setText("");
                displayNumberTextbox.setText("");   

            }

            public void clearScreen()
            {
                System.out.print('\u000C');
            }

            public String getModel()
            {
                String aModel=modelTextbox.getText();
                return aModel;

            }

            public double getPrice()
            {

                double aPrice=Double.parseDouble(priceTextbox.getText());
                return aPrice;

            }

            public int getWeight()
            {
                int aWeight=Integer.parseInt(weightTextbox.getText());
                return aWeight;

            }

            public String getSize()
            {
                String aSize=sizeTextbox.getText();
                return aSize;

            }

            public int getCredit()
            {
                int aCredit=Integer.parseInt(creditTextbox.getText());
                return aCredit;

            }

            public int getMemory()
            {
                int aMemory=Integer.parseInt(memoryTextbox.getText());
                return aMemory;

            }

            public long getPhoneNo()
            {
                long aPhoneNo=Long.parseLong(phoneNoTextbox.getText());
                return aPhoneNo;

            }
            public int getDuration()
            {
                int aDuration=Integer.parseInt(durationTextbox.getText());
                return aDuration;

            }
            public int getDownload()
            {
                int aDownload=Integer.parseInt(downloadTextbox.getText());
                return aDownload;

            }
            public int getDisplayNumber()
            {
                int aDisplayNumber=Integer.parseInt(displayNumberTextbox.getText());
                return aDisplayNumber;

            }

        }
