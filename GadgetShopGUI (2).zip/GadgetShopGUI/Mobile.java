

public class Mobile extends Gadget
{
    private int credit;
    
    private long phoneNo;
    private int duration;
    private int displayNumber;
    private int balance;
    
    public Mobile(String aModel,double aPrice, int aWeight, String aSize, int aCredit)
    {
        super(aModel,aPrice,aWeight,aSize);
        credit = aCredit;
        

    }
    
 public void MakingPhoneCall(long aPhoneNo,int aDuration,int aDisplayNumber)
 {
    phoneNo = aPhoneNo;
    duration = aDuration;
    displayNumber = aDisplayNumber;
    balance = credit - duration;
    
    
    
 }
    
    public int getCredit()
    {
        return credit;
    }

    public void printDetails()
    {
        System.out.println("..................");
        System.out.println("Mobile phone");
        System.out.println("##################");
        super.printDetails();
        System.out.println("# Credit: " + credit);
        System.out.println();
    }
    
    public void printDetailsPhoneCall()
    {
        System.out.println("..................");
        System.out.println("# Calling to: " + phoneNo);
        System.out.println("# Duration: " + balance );
    
    
    
    }
}
