

public class MP3 extends Gadget
{
    private int memory;
    
    private int download;
    private int displayNumber;
    private int balance;
    
    public MP3(String aModel,double aPrice, int aWeight, String aSize, int aMemory)
    {
        super(aModel,aPrice,aWeight,aSize);
        memory = aMemory;
    }
    
     public void DownloadMusic(int aDownload,int aDisplayNumber)
 {
    download = aDownload;
    displayNumber = aDisplayNumber;
    balance = memory - download;
    
    
    
 }
 
    public void printDetails()
    {
        System.out.println("..................");
        System.out.println("MP3 Player");
        System.out.println("##################");
        super.printDetails();
        System.out.println("# Memory: " + memory);
        System.out.println();

    }
    public void printDetailsDownloadMusic()
    {
        System.out.println("..................");
        System.out.println("# Download music: " + balance);
        
    
    
    
    }
}
